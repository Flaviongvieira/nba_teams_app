## Only run examples in interactive R sessions
library(shiny)

  ##################################################################################
  ####################################### UI #######################################
  ##################################################################################
  ui <- fluidPage(
    
    ####################################### Application title #######################################
    imageOutput("nba", width=100, height=100),
    textOutput("bbref"),
    fluidRow(
      column(5,
             
             wellPanel(style = "background: lightblue",
               selectInput("Team_1", "Choose Team 1:",
                           choices = c("Atlanta Hawks", "Boston Celtics", "Brooklyn Nets", "Charlotte Hornets", "Chicago Bulls", "Cleveland Cavaliers", "Dallas Mavericks", "Denver Nuggets", "Detroit Pistons", "Golden State Warriors", "Houston Rockets", "Indiana Pacers", "Los Angeles Clippers", "Los Angeles Lakers", "Memphis Grizzlies", "Miami Heat", "Milwaukee Bucks", "Minnesota Timberwolves", "New Orleans Pelicans", "New York Knicks", "Oklahoma City Thunder", "Orlando Magic", "Philadelphia 76ers", "Phoenix Suns", "Portland Trail Blazers", "Sacramento Kings",  "San Antonio Spurs", "Toronto Raptors", "Utah Jazz", "Washington Wizards"),
                           selected = "Golden State Warriors"),
               selectInput("Year_1", "Choose a Season for Team 1:",
                           choices = c("2019-20","2018-19","2017-18","2016-17","2015-16","2014-15","2013-14","2012-13","2011-12","2010-11","2009-10","2008-09","2007-08","2006-07","2005-06","2004-05","2003-04","2002-03","2001-02","2000-01","1999-00","1998-99","1997-98","1996-97","1995-96","1994-95","1993-94","1992-93","1991-92","1990-91","1989-90","1988-89","1987-88","1986-87","1985-86","1984-85","1983-84","1982-83","1981-82","1980-81"),
                           selected = "2018-19"
                           )
               )
             
      ),
      column(1,imageOutput("Team_1_logo", width=150, height=250)),
      column(5,
             wellPanel(style = "background: pink",
               selectInput("Team_2", "Choose Team 2:",
                           choices = c("Atlanta Hawks", "Boston Celtics", "Brooklyn Nets", "Charlotte Hornets", "Chicago Bulls", "Cleveland Cavaliers", "Dallas Mavericks", "Denver Nuggets", "Detroit Pistons", "Golden State Warriors", "Houston Rockets", "Indiana Pacers", "Los Angeles Clippers", "Los Angeles Lakers", "Memphis Grizzlies", "Miami Heat", "Milwaukee Bucks", "Minnesota Timberwolves", "New Orleans Pelicans", "New York Knicks", "Oklahoma City Thunder", "Orlando Magic", "Philadelphia 76ers", "Phoenix Suns", "Portland Trail Blazers", "Sacramento Kings",  "San Antonio Spurs", "Toronto Raptors", "Utah Jazz", "Washington Wizards"),
                           selected = "Toronto Raptors"),
               selectInput("Year_2", "Choose a Season for Team 2:",
                           choices = c("2019-20","2018-19","2017-18","2016-17","2015-16","2014-15","2013-14","2012-13","2011-12","2010-11","2009-10","2008-09","2007-08","2006-07","2005-06","2004-05","2003-04","2002-03","2001-02","2000-01","1999-00","1998-99","1997-98","1996-97","1995-96","1994-95","1993-94","1992-93","1991-92","1990-91","1989-90","1988-89","1987-88","1986-87","1985-86","1984-85","1983-84","1982-83","1981-82","1980-81"),
                           selected = "2018-19"
                           )
             )
      ),
      column(1, imageOutput("Team_2_logo", width=150, height=250)),
      
      ####################################### Plots to be displayed #######################################
      mainPanel(
        tabsetPanel(type = "pills",
          tabPanel("# Wins", 
                   textOutput("Teams_name"),
                   plotOutput("Teams_display")), 
          tabPanel("Point difference", 
                   splitLayout(
                     plotOutput("Team_1_pd_display"),
                     plotOutput("Team_2_pd_display")
                     )
                   ),
          tabPanel("Teams Overall Ratings",
                   textOutput("Paceratingexp"),
                   splitLayout(
                     plotOutput("PaceRating"),
                     plotOutput("RelativePaceRating")
                     ),
                   textOutput("Defenseratingexp"),
                   splitLayout(
                     plotOutput("DefensiveRating"),
                     plotOutput("RelativeDefensiveRating")
                     ),
                   textOutput("Ofenseratingexp"),
                   splitLayout(
                     plotOutput("OfensiveRating"),
                     plotOutput("RelativeOfensiveRating")
                   )
                   ),
          tabPanel("Season info",
                   splitLayout(
                   textOutput("finish1"),
                   textOutput("finish2")
                   ),
                   splitLayout(
                     textOutput("playOff1"),
                     textOutput("playOff2")
                   ),
                   splitLayout(
                     textOutput("coach1"),
                     textOutput("coach2")
                   ),
                   splitLayout(
                     textOutput("player1"),
                     textOutput("player2")
                   )
                   )
        )
        )
    )
  )
  ######################################################################################
  ####################################### Server #######################################
  ######################################################################################
  server <- function(input, output) {
    
    ##### libraries
    library(NBAloveR)
    library(ggplot2)
    library(tidyverse)
    library(RColorBrewer)
    library(scales)
    library(fmsb)
    library(png)

    ####################################### function to determine team codes #######################################
    team<-reactive({
      a<-franchise$Franchise
    })
    
    find_season_year<- function(season) {
      if (season == "2019-20")
        season <-2020 
      else if (season == "2018-19")
        season <-2019 
      else if (season == "2017-18")
        season <-2018 
      else if (season == "2016-17")
        season <-2017 
      else if (season == "2015-16")
        season <-2016 
      else if (season == "2014-15")
        season <-2015 
      else if (season == "2013-14")
        season <-2014 
      else if (season == "2012-13")
        season <-2013 
      else if (season == "2011-12")
        season <-2012 
      else if (season == "2010-11")
        season <-2011 
      else if (season == "2009-10")
        season <-2010 
      else if (season == "2008-09")
        season <-2009 
      else if (season == "2007-08")
        season <-2008 
      else if (season == "2006-07")
        season <-2007 
      else if (season == "2005-06")
        season <-2006 
      else if (season == "2004-05")
        season <-2005 
      else if (season == "2003-04")
        season <-2004 
      else if (season == "2002-03")
        season <-2003 
      else if (season == "2001-02")
        season <-2002 
      else if (season == "2000-01")
        season <-2001 
      else if (season == "1999-00")
        season <-2000 
      else if (season == "1998-99")
        season <-1999 
      else if (season == "1997-98")
        season <-1998 
      else if (season == "1996-97")
        season <-1997 
      else if (season == "1995-96")
        season <-1996 
      else if (season == "1994-95")
        season <-1995 
      else if (season == "1993-94")
        season <-1994 
      else if (season == "1992-93")
        season <-1993 
      else if (season == "1991-92")
        season <-1992 
      else if (season == "1990-91")
        season <-1991 
      else if (season == "1989-90")
        season <-1990 
      else if (season == "1988-89")
        season <-1989 
      else if (season == "1987-88")
        season <-1988 
      else if (season == "1986-87")
        season <-1987 
      else if (season == "1985-86")
        season <-1986 
      else if (season == "1984-85")
        season <-1985 
      else if (season == "1983-84")
        season <-1984 
      else if (season == "1982-83")
        season <-1983 
      else if (season == "1981-82")
        season <-1982 
      else if (season == "1980-81")
        season <-1981 
      else
        season
    }
    
    find_team_code <- function(team_name) {
      if (team_name == 'Atlanta Hawks')
        team_name <-'atl'
      else if (team_name == 'Boston Celtics')
        team_name <- 'bos'
      else if (team_name == 'Brooklyn Nets')
        team_name <- 'brk'
      else if (team_name == 'Charlotte Hornets')
        team_name <- 'cho'
      else if (team_name == 'Chicago Bulls')
        team_name <- 'chi'
      else if (team_name == 'Cleveland Cavaliers')
        team_name <- 'cle'
      else if (team_name == 'Dallas Mavericks')
        team_name <- 'dal'
      else if (team_name == 'Denver Nuggets')
        team_name <- 'den'
      else if (team_name == 'Detroit Pistons')
        team_name <- 'det'
      else if (team_name == 'Golden State Warriors')
        team_name <- 'gsw'
      else if (team_name == 'Houston Rockets')
        team_name <- 'hou'
      else if (team_name == 'Indiana Pacers')
        team_name <- 'ind'
      else if (team_name == 'Los Angeles Clippers')
        team_name <- 'lac'
      else if (team_name == 'Los Angeles Lakers')
        team_name <- 'lal'
      else if (team_name == 'Memphis Grizzlies')
        team_name <- 'mem'
      else if (team_name == 'Miami Heat')
        team_name <- 'mia'
      else if (team_name == 'Milwaukee Bucks')
        team_name <- 'mil'
      else if (team_name == 'Minnesota Timberwolves')
        team_name <- 'min'
      else if (team_name == 'New Orleans Pelicans')
        team_name <- 'nop'
      else if (team_name == 'New York Knicks')
        team_name <- 'nyk'
      else if (team_name == 'Oklahoma City Thunder')
        team_name <- 'okc'
      else if (team_name == 'Orlando Magic')
        team_name <- 'orl'
      else if (team_name == 'Philadelphia 76ers')
        team_name <- 'phi'
      else if (team_name == 'Phoenix Suns')
        team_name <- 'pho'
      else if (team_name == 'Portland Trail Blazers')
        team_name <- 'por'
      else if (team_name == 'Sacramento Kings')
        team_name <- 'sac'
      else if (team_name == 'San Antonio Spurs')
        team_name <- 'sas'
      else if (team_name == 'Toronto Raptors')
        team_name <- 'tor'
      else if (team_name == 'Utah Jazz')
        team_name <- 'uta'
      else if (team_name == 'Washington Wizards')
        team_name <- 'was'
      else team_name
    }
    
    output$nba <- renderImage({
      list(src = "www/nba.png",
           contentType = 'image/png',
           width = 400,
           height = 100,
           alt = 'no picture available at the moment')
    }, deleteFile = FALSE)
    
    team_1_path <- reactive({
      team_1_path <- paste("www/",names_team_1(),".png", sep = "")
    })
    
    output$Team_1_logo <- renderImage({

      list(src = team_1_path(), 
           contentType = 'image/png',
           width = 100,
           height = 100,
           alt = 'no picture available at the moment')
    }, deleteFile = FALSE)
    
    team_2_path <- reactive({
      team_path <- paste("www/",names_team_2(),".png", sep = "")
    })
    
    output$Team_2_logo <- renderImage({

      list(src = team_2_path(),
           contentType = 'image/png',
           width = 100,
           height = 100,
           alt = 'no picture available at the moment')
    }, deleteFile = FALSE)
    
    ####################################### Reactive objects #######################################
    ##### input obejcts
    team_1_name <- reactive({
      input$Team_1
    })
        names_team_1 <- reactive({
      names_team_1 <- find_team_code(team_1_name())
    })    
        team_2_name <- reactive({
      input$Team_2
    })
        names_team_2 <- reactive({
      names_team_2 <- find_team_code(team_2_name())
    })
        
    team_1_year <- reactive({
      input$Year_1
    })
    year_team_1 <- reactive({
      year_team_1 <- find_season_year(team_1_year())
    })    
    team_2_year <- reactive({
      input$Year_2
    })
    year_team_2 <- reactive({
      year_team_2 <- find_season_year(team_2_year())
    })        
        
    ##### WEB API - Find data from Basketball-Reference
    TeamA <- reactive({
      TeamA <- getMatchups(team_code = names_team_1(), season = year_team_1())
    })
    TeamB <- reactive({
      TeamB <- getMatchups(team_code = names_team_2(), season = year_team_2())
    })
    TeamA_hist <- reactive({
      getTeamHistory(team_code = names_team_1())
    })
    TeamB_hist <- reactive({
      getTeamHistory(team_code = names_team_2())
    })
    
    ##### Data transformation - Vis 1
    Team1_wins <- reactive({
      TeamA_Wins <- as.numeric(TeamA()$W)
    })
    Team1_Games <- reactive({
      TeamA_Games <- as.numeric(TeamA()$G)
    })
    Team2_wins <- reactive({
      TeamB_Wins <- as.numeric(TeamB()$W)
    })
    Team2_Games <- reactive({
      TeamB_Games <- as.numeric(TeamB()$G)
    })
    Team1_Tm <- reactive({
      as.numeric(TeamA()$Tm)
    })
    Team1_Opp <- reactive({
      as.numeric(TeamA()$Opp)
    })
    Team2_Tm <- reactive({
      as.numeric(TeamB()$Tm)
    })
    Team2_Opp <- reactive({
      as.numeric(TeamB()$Opp)
    })
    
    Team1_VS_Team2 <- reactive({
      Games <- c(Team1_Games(),Team2_Games())
      Wins <- c(Team1_wins(),Team2_wins())
      Teams <- as.factor(c(
        rep( paste(team_1_name(),year_team_1()),nrow(TeamA())),
        rep( paste(team_2_name(),year_team_2()),nrow(TeamB()))))
      team1_vs_team2_wins<-data.frame("Games"=Games,"#wins"=Wins, "Teams"=Teams)
    })
    
    ##### Data transformation - Vis 2
    pd_team_a <- reactive({
      pd_team_a <- mutate(TeamA(),pd = Team1_Tm() - Team1_Opp())
    })
    pd_team_b <- reactive({
      pd_team_b <- mutate(TeamB(),pd = Team2_Tm() - Team2_Opp())
    })
    
    ##### Data transformation - Vis 4
    
    Team_1_name_rating <- reactive({
      paste(team_1_name(),input$Year_1)
    })
    
    Team_2_name_rating <- reactive({
      paste(team_2_name(),input$Year_2)
    })
    
    Team_1_df <- reactive({
      data.frame("Team"=Team_1_name_rating(),
                 "Season"=TeamA_hist()$Season,
                 "Total # wins" = TeamA_hist()$W,
                 "Total # of loss"= TeamA_hist()$L,
                 "W/L%"= TeamA_hist()$`W/L%`,
                 "SRS" = TeamA_hist()$SRS,
                 "Pace Rating"=TeamA_hist()$Pace , 
                 "Relative Pace Rating" = TeamA_hist()$RelativePace,
                 "Ofensive Rating"= TeamA_hist()$ORtg, 
                 "Relative Ofensive Rating" = TeamA_hist()$RelativeORtg,
                 "Defensive Rating"= TeamA_hist()$DRtg,
                 "Relative Defensive Rating" = TeamA_hist()$RelativeDRtg,
                 "Finishing Place - Conference Regular Season" = TeamA_hist()$Finish,
                 "Playoff Performance" = TeamA_hist()$Playoffs,
                 "Coach" = TeamA_hist()$Coaches,
                 "Most Influence Player" = TeamA_hist()$TopWinShare
      )
    })
    
    Team_2_df <- reactive({
      data.frame("Team"=Team_2_name_rating(),
                 "Season"=TeamB_hist()$Season,
                 "Total # wins" = TeamB_hist()$W,
                 "Total # of loss"= TeamB_hist()$L,
                 "W/L%"= TeamB_hist()$`W/L%`,
                 "SRS" = TeamB_hist()$SRS,
                 "Pace Rating"=TeamB_hist()$Pace , 
                 "Relative Pace Rating" = TeamB_hist()$RelativePace,
                 "Ofensive Rating"= TeamB_hist()$ORtg, 
                 "Relative Ofensive Rating" = TeamB_hist()$RelativeORtg,
                 "Defensive Rating"= TeamB_hist()$DRtg,
                 "Relative Defensive Rating" = TeamB_hist()$RelativeDRtg,
                 "Finishing Place - Conference Regular Season" = TeamB_hist()$Finish,
                 "Playoff Performance" = TeamB_hist()$Playoffs,
                 "Coach" = TeamB_hist()$Coaches,
                 "Most Influence Player" = TeamB_hist()$TopWinShare
      )
    })
    
    Team_1_df_season <- reactive({
      Team_1_df()[Team_1_df()$Season==input$Year_1,] 
    })
    Team_2_df_season <- reactive({
      Team_2_df()[Team_2_df()$Season==input$Year_2,] 
    })
    
    Team1_Team2_df <- reactive({
      Team1_Team2_df <- rbind(Team_1_df_season(), Team_2_df_season())
    })
    
    ##### Data transformation - Vis 5
    
    Team_1_season_finish <- reactive({
      finish<-paste("Finishing place in conference regular Season: ",Team_1_df_season()$Finishing.Place...Conference.Regular.Season)
    })
    Team_1_season_playOff <- reactive({
      playOff<-paste("PlayOff performance: ", Team_1_df_season()$Playoff.Performance)
    })
    Team_1_season_coach <- reactive({
      coach<-paste("Coach: ", Team_1_df_season()$Coach)
    })
    Team_1_season_player <- reactive({
      player<-paste("Most Influential Player: ", Team_1_df_season()$Most.Influence.Player)
    })
    Team_2_season_finish <- reactive({
      finish<-paste("Finishing place in conference regular Season: ",Team_2_df_season()$Finishing.Place...Conference.Regular.Season)
    })
    Team_2_season_playOff <- reactive({
      playOff<-paste("PlayOff performance: ", Team_2_df_season()$Playoff.Performance)
    })
    Team_2_season_coach <- reactive({
      coach<-paste("Coach: ", Team_2_df_season()$Coach)
    })
    Team_2_season_player <- reactive({
      player<-paste("Most Influential Player: ", Team_2_df_season()$Most.Influence.Player)
    })
    
    ####################################### Outputs Visualizations server functions #######################################
    ##### Vis 1 - Teaam A VS Team B -> # of wins over the season
    
    output$Teams_display <- renderPlot({
      ggplot() + 
        geom_line(data = Team1_VS_Team2(), aes(x = Team1_VS_Team2()$Games, y = Team1_VS_Team2()$X.wins, color=Teams)) + 
        xlab('Games') +
        ylab('# Wins') +
        theme(
          panel.background = element_rect(fill = "gray91", colour = "gray91", size = 0.1, linetype = "solid"),
          panel.grid.major = element_line(size = 0.1, linetype = 'solid', colour = "white"), 
          panel.grid.minor = element_line(size = 0.1, linetype = 'solid', colour = "white"),
          plot.title = element_text(color="black", size=14, face="bold", hjust = 0.5),
          plot.subtitle = element_text(color = "black", face="bold")
          ) + 
        scale_x_continuous(breaks=seq(0, 82, 5)) +
        scale_y_continuous(breaks=seq(0, 60, 5)) +
        ggtitle(
          paste(team_1_name(),input$Year_1," VS ",team_2_name(),input$Year_2)
          ) + 
        scale_color_manual(values = c("blue", "red"))
    })
    
    ##### Vis 2 - Team A points difference over the season & Team B points difference over the season

    output$Team_1_pd_display <- renderPlot({
      barplot(pd_team_a()$pd, col=ifelse(pd_team_a()$pd>0,"chartreuse4","brown4"), main = paste(team_1_name(),input$Year_1))
    })

    output$Team_2_pd_display <- renderPlot({
      barplot(pd_team_b()$pd, col=ifelse(pd_team_b()$pd>0,"chartreuse4","brown4"), main = paste(team_2_name(),input$Year_2))
    })
    
    ##### Vis 4 - Team A VS Team B -> KPI (key Performance Indicators)
    output$PaceRating <- renderPlot({
      ggplot(Team1_Team2_df(), aes(x=Team, y=Pace.Rating, fill=Team)) + 
        geom_bar(stat = "Identity") + 
        ggtitle(paste("Pace Rating - ", team_1_name(),"-",input$Year_1," VS ",team_2_name(),"-",input$Year_2)) + 
        theme(
          plot.title = element_text(color="black", size=8, face="bold", hjust = 0.5)
        ) +
        xlab("Teams") + 
        scale_fill_manual(values=c("lightblue", "pink")) +
        coord_cartesian(ylim=c(0,150))
    })
    
    
    output$RelativePaceRating <- renderPlot({
      ggplot(Team1_Team2_df(), aes(x=Team, y=Relative.Pace.Rating, fill=Team)) + 
        geom_bar(stat = "Identity") + 
        ggtitle(paste("Relative Pace Rating - ", team_1_name(),"-",input$Year_1," VS ",team_2_name(),"-",input$Year_2)) + 
        theme(
          plot.title = element_text(color="black", size=8, face="bold", hjust = 0.5)
          ) +
        xlab("Teams") + 
        scale_fill_manual(values=c("lightblue", "pink"))
    })
    
    output$DefensiveRating <- renderPlot({
      ggplot(Team1_Team2_df(), aes(x=Team, y=Defensive.Rating, fill=Team)) + 
        geom_bar(stat = "Identity") + 
        ggtitle(paste("Defensive Rating - ", team_1_name(),"-",input$Year_1," VS ",team_2_name(),"-",input$Year_2)) + 
        theme(
          plot.title = element_text(color="black", size=8, face="bold", hjust = 0.5)
        ) +
        xlab("Teams") + 
        scale_fill_manual(values=c("lightblue", "pink")) +
        coord_cartesian(ylim=c(0,150))
    })
    
    output$RelativeDefensiveRating <- renderPlot({
      ggplot(Team1_Team2_df(), aes(x=Team, y=Relative.Defensive.Rating, fill=Team)) + 
        geom_bar(stat = "Identity") + 
        ggtitle(paste("Relative Defensive Rating - ", team_1_name(),"-",input$Year_1," VS ",team_2_name(),"-",input$Year_2)) + 
        theme(
          plot.title = element_text(color="black", size=8, face="bold", hjust = 0.5)
        ) +
        xlab("Teams") + 
        scale_fill_manual(values=c("lightblue", "pink"))
    })
    output$OfensiveRating <- renderPlot({
      ggplot(Team1_Team2_df(), aes(x=Team, y=Ofensive.Rating, fill=Team)) + 
        geom_bar(stat = "Identity") + 
        ggtitle(paste("Ofensive Rating - ", team_1_name(),"-",input$Year_1," VS ",team_2_name(),"-",input$Year_2)) + 
        theme(
          plot.title = element_text(color="black", size=8, face="bold", hjust = 0.5)
        ) +
        xlab("Teams") + 
        scale_fill_manual(values=c("lightblue", "pink")) +
        coord_cartesian(ylim=c(0,150))
    })
    
    output$RelativeOfensiveRating <- renderPlot({
      ggplot(Team1_Team2_df(), aes(x=Team, y=Relative.Ofensive.Rating, fill=Team)) + 
        geom_bar(stat = "Identity") + 
        ggtitle(paste("Relative Ofensive Rating - ", team_1_name(),"-",input$Year_1," VS ",team_2_name(),"-",input$Year_2)) + 
        theme(
          plot.title = element_text(color="black", size=8, face="bold", hjust = 0.5)
        ) +
        xlab("Teams") + 
        scale_fill_manual(values=c("lightblue", "pink"))
    })
    
    output$Paceratingexp <- renderText({
      print("Pace Factor is the extimate of possesions in 48 minutes and Relative Pace is the team's possion  in 48 minutes relative to the league")
    })
    
    output$Ofenseratingexp <- renderText({
      print("Offensive Rating is the estimate of points scored in 100 possessions and the Relative Offensive Rating is the estimate of points scored in 100 possessios relative to the league")
    })
    
    output$Defenseratingexp <- renderText({
      print("Defensive Rating is the estimate of points allowed in 100 possessions and Relative Defensive Rating is the estimate of points allowed in 100 possessios relative to the league")
    })
    
    ##### Vis 5 - Season info from both teams
    
    output$finish1 <- renderText({
      print(Team_1_season_finish()
      )
    })
    output$playOff1 <- renderText({
      print(Team_1_season_playOff()
      )
    })
    output$coach1 <- renderText({
      print(Team_1_season_coach()
      )
    })
    output$player1 <- renderText({
      print(Team_1_season_player()
      )
    })
    output$finish2 <- renderText({
      print(Team_2_season_finish()
      )
    })
    output$playOff2 <- renderText({
      print(Team_2_season_playOff()
      )
    })
    output$coach2 <- renderText({
      print(Team_2_season_coach()
      )
    })
    output$player2 <- renderText({
      print(Team_2_season_player()
      )
    })
    output$bbref <- renderText({
      print(paste("Data sourced from: www.basketball-reference.com")
      )
    })
  }
  ##########################################################################################################################
  ####################################### Complete app with UI and server components #######################################
  ##########################################################################################################################
  shinyApp(ui, server)
  